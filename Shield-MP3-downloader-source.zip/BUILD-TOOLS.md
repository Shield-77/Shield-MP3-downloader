# External CIA build tools

The source archive does not redistribute `makerom` or `bannertool` executables. Download compatible builds separately from their projects and review their terms before use:

- makerom: https://github.com/3DSGuy/Project_CTR
- bannertool: https://github.com/carstene1ns/3ds-bannertool

Place the binaries at the paths referenced by the Makefile in `resource/tools/`. The application source retains its own upstream notices and licenses.
