#include "headers.hpp"
#include "audio_exporter.hpp"

#ifdef MP3_DOWNLOADER_APP
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/channel_layout.h>
#include <libavutil/error.h>
#include <libavutil/samplefmt.h>
#include <libswresample/swresample.h>
#include <layer3.h>
}

#include <atomic>
#include <cctype>
#include <cstdio>
#include <sys/stat.h>
#include <curl/curl.h>

namespace {
std::atomic<int> state((int)AudioExportState::IDLE);
std::atomic<int> progress(0);
std::atomic<int> selected_bitrate(128);
std::atomic<bool> selected_artwork(true);
std::atomic<bool> cancel_requested(false);
std::atomic<bool> stop_requested(false);
std::atomic<bool> request_pending(false);
std::atomic<bool> player_stopped(false);
std::atomic<bool> wait_for_player(false);
std::atomic<bool> duration_limit_rejected(false);
std::atomic<bool> resumable_partial(false);
std::atomic<bool> conversion_failed(false);
std::atomic<bool> artwork_embedded(false);
std::atomic<int> conversion_error_code(0);
std::string last_error_detail;
static const int MP3_OUTPUT_SAMPLE_RATE = 44100;
std::string requested_url;
std::string requested_title;
std::string requested_id;
long long requested_duration_ms = 0;
long long requested_size = 0;
long long download_offset = 0;
Thread worker_thread = 0;

struct DownloadContext {
	FILE *file;
};

size_t curl_write_file(char *data, size_t size, size_t count, void *user_data) {
	DownloadContext *context = (DownloadContext *)user_data;
	size_t bytes = size * count;
	if (cancel_requested.load()) return 0;
	return fwrite(data, 1, bytes, context->file);
}

int curl_update_progress(void *, curl_off_t total, curl_off_t current, curl_off_t, curl_off_t) {
	if (cancel_requested.load()) return 1;
	long long total_size = requested_size > 0 ? requested_size : (total > 0 ? download_offset + total : 0);
	if (total_size > 0) {
		int value = (int)std::min<long long>(99, (download_offset + current) * 100 / total_size);
		progress.store(value);
	}
	return 0;
}

size_t curl_write_art(char *data, size_t size, size_t count, void *user_data) {
	std::vector<unsigned char> *image = (std::vector<unsigned char> *)user_data;
	if (cancel_requested.load() || (size && count > SIZE_MAX / size)) return 0;
	size_t bytes = size * count;
	if (bytes > 128 * 1024 - image->size()) return 0;
	image->insert(image->end(), (unsigned char *)data, (unsigned char *)data + bytes);
	return bytes;
}

int curl_art_progress(void *, curl_off_t, curl_off_t, curl_off_t, curl_off_t) {
	return cancel_requested.load() ? 1 : 0;
}

bool fetch_album_art(const std::string &id, std::vector<unsigned char> &image) {
	if (id.size() != 11) return false;
	for (unsigned char c : id)
		if (!std::isalnum(c) && c != '-' && c != '_') return false;
	std::string url = "https://i.ytimg.com/vi/" + id + "/mqdefault.jpg";
	CURL *curl = curl_easy_init();
	if (!curl) return false;
	curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
	curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
	curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
	curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
	curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 7L);
	curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);
	curl_easy_setopt(curl, CURLOPT_USERAGENT, "Shield MP3 Downloader/3DS");
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_write_art);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &image);
	curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, curl_art_progress);
	curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
	CURLcode result = curl_easy_perform(curl);
	long status = 0;
	curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
	curl_easy_cleanup(curl);
	bool valid = result == CURLE_OK && status == 200 && image.size() >= 4 &&
	             image[0] == 0xff && image[1] == 0xd8 &&
	             image[image.size() - 2] == 0xff && image.back() == 0xd9;
	if (!valid) image.clear();
	return valid;
}

void syncsafe32(unsigned char *out, uint32_t value) {
	out[0] = (value >> 21) & 0x7f;
	out[1] = (value >> 14) & 0x7f;
	out[2] = (value >> 7) & 0x7f;
	out[3] = value & 0x7f;
}

bool write_id3_frame_header(FILE *output, const char *name, uint32_t size) {
	unsigned char header[10] = {};
	memcpy(header, name, 4);
	syncsafe32(header + 4, size);
	return fwrite(header, 1, sizeof(header), output) == sizeof(header);
}

bool write_id3_tag(FILE *output, const std::string &title,
	               const std::vector<unsigned char> &image) {
	const size_t title_bytes = std::min<size_t>(title.size(), 1024);
	const uint32_t title_frame_size = (uint32_t)title_bytes + 1;
	const uint32_t art_frame_size = image.empty() ? 0 : (uint32_t)image.size() + 14;
	const uint32_t body_size = 10 + title_frame_size + (art_frame_size ? 10 + art_frame_size : 0);
	unsigned char header[10] = {'I', 'D', '3', 4, 0, 0, 0, 0, 0, 0};
	syncsafe32(header + 6, body_size);
	const unsigned char utf8 = 3;
	if (fwrite(header, 1, sizeof(header), output) != sizeof(header) ||
	    !write_id3_frame_header(output, "TIT2", title_frame_size) ||
	    fwrite(&utf8, 1, 1, output) != 1 ||
	    fwrite(title.data(), 1, title_bytes, output) != title_bytes) return false;
	if (!art_frame_size) return true;
	const unsigned char art_prefix[] = {3, 'i', 'm', 'a', 'g', 'e', '/', 'j', 'p', 'e', 'g', 0, 3, 0};
	return write_id3_frame_header(output, "APIC", art_frame_size) &&
	       fwrite(art_prefix, 1, sizeof(art_prefix), output) == sizeof(art_prefix) &&
	       fwrite(image.data(), 1, image.size(), output) == image.size();
}

std::string audio_source_key(const std::string &url, long long expected_size) {
	std::string key;
	size_t itag = url.find("itag=");
	if (itag != std::string::npos) {
		itag += 5;
		size_t end = url.find_first_not_of("0123456789", itag);
		key = url.substr(itag, end == std::string::npos ? end : end - itag);
	}
	if (key.empty()) key = "unknown";
	if (expected_size > 0) key += "_" + std::to_string(expected_size);
	return key;
}

std::string make_safe_name(const std::string &title, const std::string &id) {
	std::string result;
	result.reserve(64);
	for (unsigned char c : title) {
		if (result.size() >= 48) break;
		if (std::isalnum(c) || c == ' ' || c == '-' || c == '_') result.push_back((char)c);
		else if (c >= 0x80) result.push_back('_');
	}
	while (!result.empty() && result.back() == ' ') result.pop_back();
	if (result.empty()) result = "YouTube audio";
	if (!id.empty()) result += "_" + id;
	return result;
}

// Stable codes shown on the 3DS screen so conversion failures can be reported
// without needing to read the console log.
int get_conversion_error_code(const std::string &error) {
	if (error.find("Cannot open downloaded audio") != std::string::npos) return 1;
	if (error.find("Cannot read audio stream") != std::string::npos) return 2;
	if (error.find("No supported audio stream") != std::string::npos) return 3;
	if (error.find("audio decoder") != std::string::npos || error.find("AAC decoder") != std::string::npos ||
	    error.find("AAC packet") != std::string::npos) return 4;
	if (error.find("audio format") != std::string::npos || error.find("resampling") != std::string::npos) return 5;
	if (error.find("bitrate") != std::string::npos) return 6;
	if (error.find("MP3 encoder") != std::string::npos || error.find("MP3 encoding") != std::string::npos) return 7;
	if (error.find("create MP3") != std::string::npos) return 8;
	if (error.find("memory") != std::string::npos) return 9;
	if (error.find("write") != std::string::npos || error.find("SD card") != std::string::npos) return 10;
	if (error.find("close MP3 file") != std::string::npos) return 10;
	if (error.find("incomplete or unreadable") != std::string::npos) return 11;
	return 99;
}

bool write_encoded_samples(shine_t encoder, FILE *output, std::vector<int16_t> &buffer, size_t &buffered_samples,
                           const int16_t *samples, size_t sample_count) {
	const size_t frame_samples = shine_samples_per_pass(encoder);
	while (sample_count) {
		size_t available = frame_samples - buffered_samples;
		size_t copy_count = std::min(available, sample_count);
		memcpy(buffer.data() + buffered_samples * 2, samples, copy_count * 2 * sizeof(int16_t));
		buffered_samples += copy_count;
		samples += copy_count * 2;
		sample_count -= copy_count;
		if (buffered_samples == frame_samples) {
			int written = 0;
			unsigned char *encoded = shine_encode_buffer_interleaved(encoder, buffer.data(), &written);
			if (written < 0 || (written && fwrite(encoded, 1, written, output) != (size_t)written)) return false;
			buffered_samples = 0;
		}
	}
	return true;
}

bool encode_file(const std::string &input_path, const std::string &output_path, long long duration_ms,
                 const std::string &title, const std::vector<unsigned char> &image, std::string &error) {
	AVFormatContext *format = NULL;
	AVCodecContext *decoder = NULL;
	const AVCodec *codec = NULL;
	AVPacket *packet = NULL;
	AVFrame *frame = NULL;
	SwrContext *resampler = NULL;
	shine_t encoder = NULL;
	FILE *output = NULL;
	uint8_t *converted = NULL;
	bool ok = false;
	int audio_stream_index = -1;

	// FFmpeg otherwise parses "sdmc:" as an unsupported URL protocol instead
	// of opening the libctru-mounted SD path as a local file.
	std::string input_url = "file:" + input_path;
	int result = avformat_open_input(&format, input_url.c_str(), NULL, NULL);
	if (result < 0) {
		char error_buffer[AV_ERROR_MAX_STRING_SIZE];
		av_strerror(result, error_buffer, sizeof(error_buffer));
		error = std::string("Cannot open downloaded audio: ") + error_buffer;
		goto cleanup;
	}
	result = avformat_find_stream_info(format, NULL);
	if (result < 0) { error = "Cannot read audio stream"; goto cleanup; }
	{
		audio_stream_index = av_find_best_stream(format, AVMEDIA_TYPE_AUDIO, -1, -1, &codec, 0);
		if (audio_stream_index < 0 || !codec) { error = "No supported audio stream"; goto cleanup; }
		decoder = avcodec_alloc_context3(codec);
		if (!decoder) { error = "Not enough memory for audio decoder"; goto cleanup; }
		// Force a single decoder thread before opening the codec to keep Old 3DS RAM use low.
		decoder->thread_count = 1;
		if (avcodec_parameters_to_context(decoder, format->streams[audio_stream_index]->codecpar) < 0 ||
		    avcodec_open2(decoder, codec, NULL) < 0) {
			error = "Could not start audio decoder";
			goto cleanup;
		}
		resampler = swr_alloc_set_opts(NULL, AV_CH_LAYOUT_STEREO, AV_SAMPLE_FMT_S16, MP3_OUTPUT_SAMPLE_RATE,
		                               av_get_default_channel_layout(decoder->channels), decoder->sample_fmt,
		                               decoder->sample_rate, 0, NULL);
		if (!resampler || swr_init(resampler) < 0) { error = "Could not convert audio format"; goto cleanup; }
	}

	{
		shine_config_t config;
		shine_set_config_mpeg_defaults(&config.mpeg);
		config.mpeg.bitr = selected_bitrate.load();
		config.mpeg.mode = STEREO;
		config.wave.samplerate = MP3_OUTPUT_SAMPLE_RATE;
		config.wave.channels = PCM_STEREO;
		if (shine_check_config(config.wave.samplerate, config.mpeg.bitr) < 0) {
			error = "Selected MP3 bitrate is unsupported";
			goto cleanup;
		}
		encoder = shine_initialise(&config);
		if (!encoder) { error = "Not enough memory for MP3 encoder"; goto cleanup; }
	}

	output = fopen(output_path.c_str(), "wb");
	if (!output) { error = "Cannot create MP3 file on SD card"; goto cleanup; }
	setvbuf(output, NULL, _IOFBF, 16384);
	if (!write_id3_tag(output, title, image)) { error = "Could not write MP3 cover or title"; goto cleanup; }
	packet = av_packet_alloc();
	frame = av_frame_alloc();
	if (!packet || !frame) { error = "Not enough memory to convert audio"; goto cleanup; }

	{
		std::vector<int16_t> sample_buffer((size_t)shine_samples_per_pass(encoder) * 2);
		size_t buffered_samples = 0;
		int converted_capacity = 4096;
		if (av_samples_alloc(&converted, NULL, 2, converted_capacity, AV_SAMPLE_FMT_S16, 0) < 0) {
			error = "Not enough memory for audio conversion";
			goto cleanup;
		}
		auto receive_frames = [&]() -> bool {
			int receive_result;
			while ((receive_result = avcodec_receive_frame(decoder, frame)) == 0) {
				if (cancel_requested.load()) return false;
				int sample_capacity = swr_get_out_samples(resampler, frame->nb_samples);
				if (sample_capacity > converted_capacity) {
					av_freep(&converted);
					converted_capacity = sample_capacity;
					if (av_samples_alloc(&converted, NULL, 2, converted_capacity, AV_SAMPLE_FMT_S16, 0) < 0)
						return false;
				}
				uint8_t *out_planes[1] = {converted};
				int count = swr_convert(resampler, out_planes, converted_capacity,
				                        (const uint8_t **)frame->extended_data, frame->nb_samples);
				if (count < 0) {
					error = "Audio resampling failed";
					return false;
				}
				if (!write_encoded_samples(encoder, output, sample_buffer, buffered_samples,
				                           (const int16_t *)converted, count)) {
					error = "MP3 encoding or SD write failed";
					return false;
				}
				if (duration_ms > 0 && frame->pts != AV_NOPTS_VALUE) {
					int64_t timestamp_ms = av_rescale_q(frame->pts, format->streams[audio_stream_index]->time_base,
					                                   (AVRational){1, 1000});
					progress.store((int)std::min<int64_t>(99, std::max<int64_t>(0, timestamp_ms * 100 / duration_ms)));
				}
				av_frame_unref(frame);
			}
			if (cancel_requested.load()) return false;
			if (receive_result == AVERROR(EAGAIN) || receive_result == AVERROR_EOF) return true;
			char error_buffer[AV_ERROR_MAX_STRING_SIZE];
			av_strerror(receive_result, error_buffer, sizeof(error_buffer));
			error = std::string("AAC decoder failed: ") + error_buffer;
			return false;
		};

		int read_result = 0;
		while (!cancel_requested.load() && (read_result = av_read_frame(format, packet)) >= 0) {
			if (packet->stream_index == audio_stream_index) {
				result = avcodec_send_packet(decoder, packet);
				if (result < 0) {
					av_packet_unref(packet);
					char error_buffer[AV_ERROR_MAX_STRING_SIZE];
					av_strerror(result, error_buffer, sizeof(error_buffer));
					error = std::string("AAC packet rejected: ") + error_buffer;
					goto cleanup;
				}
				if (!receive_frames()) { av_packet_unref(packet); goto cleanup; }
			}
			av_packet_unref(packet);
		}
		if (cancel_requested.load()) { error = "Cancelled"; goto cleanup; }
		if (read_result != AVERROR_EOF) { error = "Downloaded audio is incomplete or unreadable"; goto cleanup; }
		avcodec_send_packet(decoder, NULL);
		if (!receive_frames()) {
			if (error.empty()) error = "Audio conversion failed";
			goto cleanup;
		}
		if (buffered_samples) {
			memset(sample_buffer.data() + buffered_samples * 2, 0,
			       (sample_buffer.size() / 2 - buffered_samples) * 2 * sizeof(int16_t));
			int written = 0;
			unsigned char *encoded = shine_encode_buffer_interleaved(encoder, sample_buffer.data(), &written);
			if (written < 0 || (written && fwrite(encoded, 1, written, output) != (size_t)written)) {
				error = "Could not write MP3 data";
				goto cleanup;
			}
		}
		int written = 0;
		unsigned char *encoded = shine_flush(encoder, &written);
		if (written < 0 || (written && fwrite(encoded, 1, written, output) != (size_t)written)) {
			error = "Could not finish MP3 file";
			goto cleanup;
		}
	}
	ok = true;

cleanup:
	if (output) {
		if (fflush(output) != 0) { ok = false; error = "Could not finish writing to SD card"; }
		if (fclose(output) != 0) { ok = false; error = "Could not close MP3 file on SD card"; }
	}
	if (converted) av_freep(&converted);
	if (frame) av_frame_free(&frame);
	if (packet) av_packet_free(&packet);
	if (resampler) swr_free(&resampler);
	if (decoder) avcodec_free_context(&decoder);
	if (format) avformat_close_input(&format);
	if (encoder) shine_close(encoder);
	return ok;
}

bool download_and_convert(const std::string &url, const std::string &title, const std::string &id,
                          long long duration_ms, long long expected_size, bool include_artwork, std::string &saved_name,
                          std::string &error) {
	const char *directory = "sdmc:/download audio";
	if (mkdir(directory, 0777) != 0 && errno != EEXIST) { error = "Could not create download audio folder"; return false; }
	std::string base = make_safe_name(title, id);
	std::string output_path = std::string(directory) + "/" + base + ".mp3";
	for (int suffix = 1; Path(output_path).is_file(); suffix++) {
		output_path = std::string(directory) + "/" + base + " (" + std::to_string(suffix) + ").mp3";
	}
	std::string input_path = output_path + ".source_" + audio_source_key(url, expected_size) + ".tmp";
	long long offset = 0;
	struct stat partial_stat;
	if (stat(input_path.c_str(), &partial_stat) == 0 && partial_stat.st_size > 0 &&
	    (expected_size <= 0 || partial_stat.st_size < expected_size)) {
		offset = partial_stat.st_size;
	} else {
		std::remove(input_path.c_str());
	}
	resumable_partial.store(offset > 0);
	bool downloaded = expected_size > 0 && offset == expected_size;
	if (expected_size > 0 && offset == expected_size) {
		progress.store(99);
	} else {
		DownloadContext context = {NULL};
	CURL *curl = curl_easy_init();
	if (!curl) { error = "Could not start network download"; return false; }
	struct curl_slist *headers = NULL;
	headers = curl_slist_append(headers, "Accept: */*");
	headers = curl_slist_append(headers, "User-Agent: Mozilla/5.0 (Nintendo 3DS; FourthTube MP3 Downloader)");
	bool write_failed = false;
	CURLcode curl_result = CURLE_OK;
	long status_code = 0;
	for (int attempt = 0; attempt < 3 && !cancel_requested.load(); attempt++) {
		FILE *file = fopen(input_path.c_str(), offset > 0 ? "ab" : "wb");
		if (!file) { error = "Could not open temporary audio file on SD"; break; }
        // Larger sequential-I/O buffers reduce callback and SD write overhead
        // without a meaningful Old 3DS memory cost (32 KiB each).
        setvbuf(file, NULL, _IOFBF, 32768);
		context.file = file;
		curl_easy_reset(curl);
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
		curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
		curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
		curl_easy_setopt(curl, CURLOPT_BUFFERSIZE, 32768L);
		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_write_file);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &context);
		curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, curl_update_progress);
		curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
		curl_easy_setopt(curl, CURLOPT_FAILONERROR, 1L);
		if (offset > 0) curl_easy_setopt(curl, CURLOPT_RESUME_FROM_LARGE, (curl_off_t)offset);
		download_offset = offset;
		curl_result = curl_easy_perform(curl);
		status_code = 0;
		curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status_code);
		write_failed = ferror(file) != 0 || fflush(file) != 0;
		if (fclose(file) != 0) write_failed = true;
		if (cancel_requested.load()) break;
		// Some CDNs ignore Range. Drop the partial file and retry from byte zero.
		if (offset > 0 && status_code == 200) {
			std::remove(input_path.c_str());
			offset = 0;
			resumable_partial.store(false);
			continue;
		}
		bool expected_size_matches = true;
		if (expected_size > 0) {
			struct stat downloaded_stat;
			expected_size_matches = stat(input_path.c_str(), &downloaded_stat) == 0 &&
			                        downloaded_stat.st_size == expected_size;
		}
		if (curl_result == CURLE_OK && status_code >= 200 && status_code < 300 && !write_failed &&
		    expected_size_matches) {
			downloaded = true;
			break;
		}
		if (stat(input_path.c_str(), &partial_stat) == 0) offset = partial_stat.st_size;
		if (expected_size > 0 && offset >= expected_size) {
			if (offset == expected_size) { downloaded = true; break; }
			std::remove(input_path.c_str());
			offset = 0;
		}
		resumable_partial.store(offset > 0);
		if (attempt < 2) svcSleepThread(500000000LL);
	}
	curl_slist_free_all(headers);
	curl_easy_cleanup(curl);
	}
	if (!downloaded || cancel_requested.load()) {
		if (cancel_requested.load()) {
			std::remove(input_path.c_str());
			resumable_partial.store(false);
			error = "Cancelled";
		} else if (!error.empty()) {
			// Keep the specific filesystem/network setup error.
		} else if (resumable_partial.load()) {
			error = "Download interrupted; partial audio kept for resume";
		} else {
			error = "Audio download failed (network or SD card)";
		}
		return false;
	}

	std::vector<unsigned char> cover_image;
	if (include_artwork) {
		state.store((int)AudioExportState::FETCHING_ART);
		(void)fetch_album_art(id, cover_image);
	}
	if (cancel_requested.load()) {
		std::remove(input_path.c_str());
		error = "Cancelled";
		return false;
	}
	state.store((int)AudioExportState::ENCODING);
	progress.store(0);
	if (!encode_file(input_path, output_path, duration_ms, title, cover_image, error)) {
		struct stat source_stat;
		bool keep_complete_source = expected_size > 0 && stat(input_path.c_str(), &source_stat) == 0 &&
		                            source_stat.st_size == expected_size;
		if (!keep_complete_source) std::remove(input_path.c_str());
		std::remove(output_path.c_str());
		resumable_partial.store(keep_complete_source);
		conversion_failed.store(true);
		conversion_error_code.store(get_conversion_error_code(error));
		return false;
	}
	conversion_failed.store(false);
	conversion_error_code.store(0);
	artwork_embedded.store(!cover_image.empty());
	std::remove(input_path.c_str());
	resumable_partial.store(false);
	saved_name = output_path;
	return true;
}

void worker(void *) {
	while (!stop_requested.load()) {
		if (!request_pending.exchange(false)) { svcSleepThread(100000000LL); continue; }
		if (wait_for_player.load()) {
			while (!player_stopped.load() && !cancel_requested.load() && !stop_requested.load())
				svcSleepThread(100000000LL);
		}
		if (cancel_requested.load() || stop_requested.load()) {
			state.store((int)AudioExportState::CANCELLED);
			continue;
		}
		state.store((int)AudioExportState::DOWNLOADING);
		progress.store(0);
		std::string url = requested_url, title = requested_title, id = requested_id;
		std::string saved_name, error;
		bool success = download_and_convert(url, title, id, requested_duration_ms, requested_size,
		                                    selected_artwork.load(), saved_name, error);
		last_error_detail = error;
		if (cancel_requested.load()) state.store((int)AudioExportState::CANCELLED);
		else state.store((int)(success ? AudioExportState::DONE : AudioExportState::FAILED));
		if (success) logger.info("mp3", "Saved audio file: " + saved_name);
		else if (!cancel_requested.load()) logger.error("mp3", error);
	}
	threadExit(0);
}
} // namespace

void AudioExport_init() {
	stop_requested.store(false);
	cancel_requested.store(false);
	request_pending.store(false);
	player_stopped.store(true);
	state.store((int)AudioExportState::IDLE);
	worker_thread = threadCreate(worker, NULL, DEF_STACKSIZE, DEF_THREAD_PRIORITY_NORMAL, 1, false);
	if (!worker_thread) state.store((int)AudioExportState::FAILED);
}

void AudioExport_exit() {
	if (!worker_thread) return;
	cancel_requested.store(true);
	stop_requested.store(true);
	// The worker owns curl/FFmpeg and its files; never free its handle while it
	// can still be running. Its cancellation checks make this join bounded by I/O.
	Result join_result = threadJoin(worker_thread, UINT64_MAX);
	if (R_FAILED(join_result)) {
		logger.error("mp3", "Could not join audio export worker: " + std::to_string(join_result));
		return;
	}
	threadFree(worker_thread);
	worker_thread = 0;
}

void AudioExport_begin(const std::string &url, const std::string &title, const std::string &video_id,
                       int64_t duration_ms, long long expected_size) {
	if (state.load() != (int)AudioExportState::IDLE) return;
	duration_limit_rejected.store(duration_ms <= 0 || duration_ms > 60 * 60 * 1000);
	if (duration_limit_rejected.load()) {
		state.store((int)AudioExportState::FAILED);
		return;
	}
	requested_url = url;
	requested_title = title;
	requested_id = video_id;
	requested_duration_ms = duration_ms;
	requested_size = expected_size;
	selected_bitrate.store(128);
	selected_artwork.store(true);
	progress.store(0);
	cancel_requested.store(false);
	resumable_partial.store(false);
	conversion_failed.store(false);
	artwork_embedded.store(false);
	conversion_error_code.store(0);
	last_error_detail.clear();
	player_stopped.store(false);
	state.store((int)AudioExportState::SELECT_BITRATE);
}

void AudioExport_choose_bitrate(int bitrate_kbps) {
	if (state.load() != (int)AudioExportState::SELECT_BITRATE || (bitrate_kbps != 128 && bitrate_kbps != 256)) return;
	selected_bitrate.store(bitrate_kbps);
	state.store((int)AudioExportState::SELECT_ARTWORK);
}

void AudioExport_choose_artwork(bool include_artwork) {
	if (state.load() != (int)AudioExportState::SELECT_ARTWORK) return;
	selected_artwork.store(include_artwork);
	state.store((int)AudioExportState::CONFIRM);
}

void AudioExport_confirm(bool wait_for_player_stop) {
	if (state.load() != (int)AudioExportState::CONFIRM) return;
	wait_for_player.store(wait_for_player_stop);
	player_stopped.store(!wait_for_player_stop);
	state.store((int)AudioExportState::WAITING_FOR_PLAYER);
	request_pending.store(true);
}

void AudioExport_notify_player_stopped() { player_stopped.store(true); }
void AudioExport_cancel_prompt() {
	if (state.load() == (int)AudioExportState::SELECT_BITRATE ||
	    state.load() == (int)AudioExportState::SELECT_ARTWORK ||
	    state.load() == (int)AudioExportState::CONFIRM)
		state.store((int)AudioExportState::IDLE);
}
void AudioExport_cancel_operation() { cancel_requested.store(true); }
void AudioExport_dismiss() {
	if (state.load() == (int)AudioExportState::DONE || state.load() == (int)AudioExportState::FAILED ||
	    state.load() == (int)AudioExportState::CANCELLED)
		state.store((int)AudioExportState::IDLE);
}
AudioExportState AudioExport_get_state() { return (AudioExportState)state.load(); }
int AudioExport_get_progress() { return progress.load(); }
int AudioExport_get_bitrate() { return selected_bitrate.load(); }

void AudioExport_draw_overlay() {
	AudioExportState current = AudioExport_get_state();
	if (current == AudioExportState::IDLE) return;
	Draw_texture(var_square_image[0], DEF_DRAW_BLACK, 18, 78, 364, 86);
	bool show_progress = current == AudioExportState::DOWNLOADING || current == AudioExportState::ENCODING;
	if (show_progress) {
		Draw_texture(var_square_image[0], 0xFF555555, 30, 143, 340, 8);
		Draw_texture(var_square_image[0], 0xFF30A0E0, 30, 143, 340 * AudioExport_get_progress() / 100.0f, 8);
	}
	std::string line1, line2, line3;
	switch (current) {
		case AudioExportState::SELECT_BITRATE:
			line1 = "MP3 output bitrate";
			line2 = "A:128 kbps  X:256 kbps  B:Cancel";
			line3 = "Source audio quality may be lower";
			break;
		case AudioExportState::SELECT_ARTWORK:
			line1 = "Include video thumbnail in MP3?";
			line2 = "A: With cover   B: Without";
			line3 = "X: Cancel";
			break;
		case AudioExportState::CONFIRM:
			line1 = "Create MP3 at " + std::to_string(AudioExport_get_bitrate()) + " kbps?";
			line2 = "A: Yes    B: Cancel";
			line3 = selected_artwork.load() ? "Cover: included if available" : "Cover: not included";
			break;
		case AudioExportState::WAITING_FOR_PLAYER:
			line1 = "Preparing audio export...";
			line2 = "Stopping playback to free memory";
			break;
		case AudioExportState::DOWNLOADING:
			line1 = "Downloading audio: " + std::to_string(AudioExport_get_progress()) + "%";
			line2 = "B: Cancel";
			break;
		case AudioExportState::FETCHING_ART:
			line1 = "Preparing MP3 cover art...";
			line2 = "B: Cancel";
			line3 = "Audio still saves if art is unavailable";
			break;
		case AudioExportState::ENCODING:
			line1 = "Converting to MP3: " + std::to_string(AudioExport_get_progress()) + "%";
			line2 = "B: Cancel";
			break;
		case AudioExportState::DONE:
			line1 = "MP3 saved to SD:/download audio";
			line2 = "A or B: Close";
			line3 = artwork_embedded.load() ? "Cover art included in MP3" : "Cover unavailable; audio saved";
			break;
		case AudioExportState::FAILED:
			line1 = duration_limit_rejected.load() ? "Unknown or >1h audio blocked"
			                                      : conversion_failed.load() ? "MP3 conversion failed"
			                                      : resumable_partial.load() ? "Download interrupted; partial kept"
			                                                                 : "MP3 export failed";
			line2 = conversion_failed.load() ? std::string("E") +
			                                       (conversion_error_code.load() < 10 ? "0" : "") +
			                                       std::to_string(conversion_error_code.load()) + "  A/B close  Y retry"
			                                  : resumable_partial.load() ? "Source kept; A/B close, Y retry"
			                                                             : "Network/SD error  A: Close";
			if (conversion_failed.load() && !last_error_detail.empty()) {
				size_t detail_start = last_error_detail.find(": ");
				line3 = last_error_detail.substr(detail_start == std::string::npos ? 0 : detail_start + 2, 46);
				if (last_error_detail.size() - (detail_start == std::string::npos ? 0 : detail_start + 2) > 46)
					line3 += "...";
			}
			break;
		case AudioExportState::CANCELLED:
			line1 = "MP3 export cancelled";
			line2 = "A or B: Close";
			break;
		default: return;
	}
	Draw_xy_centered(line1, 24, 376, 91, 116, 0.65, 0.65, DEFAULT_TEXT_COLOR);
	Draw_xy_centered(line2, 24, 376, 116, 137, 0.45, 0.45, DEFAULT_TEXT_COLOR);
	if (!line3.empty()) Draw_xy_centered(line3, 24, 376, 138, 159, 0.4, 0.4, DEFAULT_TEXT_COLOR);
}

#else
void AudioExport_init() {}
void AudioExport_exit() {}
void AudioExport_begin(const std::string &, const std::string &, const std::string &, int64_t, long long) {}
void AudioExport_choose_bitrate(int) {}
void AudioExport_choose_artwork(bool) {}
void AudioExport_confirm(bool) {}
void AudioExport_notify_player_stopped() {}
void AudioExport_cancel_prompt() {}
void AudioExport_cancel_operation() {}
void AudioExport_dismiss() {}
AudioExportState AudioExport_get_state() { return AudioExportState::IDLE; }
int AudioExport_get_progress() { return 0; }
int AudioExport_get_bitrate() { return 128; }
void AudioExport_draw_overlay() {}
#endif
