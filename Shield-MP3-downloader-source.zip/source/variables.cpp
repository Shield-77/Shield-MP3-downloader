#include "headers.hpp"

bool var_connect_test_success = false;
bool var_need_refresh = true;
bool var_allow_send_app_info = false;
bool var_hide_pointer = false;
bool var_night_mode = false;
bool var_disable_pull_to_refresh = false;
bool var_eco_mode = true;
bool var_debug_mode = false;
bool var_history_enabled = true;
bool var_oauth_enabled = false;
int var_autoplay_level = 2; // 0 : never, 1 : only in a playlist, 2 : always
int var_loop_mode = false;
int var_video_quality = 0;
bool var_show_fps = false;
bool var_full_screen_mode = false;
bool var_full_dislike_like_count = false;
bool var_video_show_debug_info = false;
int var_player_response = 1; // 0 : Android, 1 : Android VR, 2 : visionOS (interm 34.1 has 1 as for now 0 is 100% broken 1 is only broken for kids right now, stop gap hence the interm release)
bool var_video_linear_filter = true;
// Use the full forward window by default. The downloader still enforces the
// Old 3DS cache cap, so this improves tolerance to Wi-Fi jitter without
// allocating more stream memory.
double var_forward_buffer_ratio = 1.0;
u8 var_wifi_state = 0;
u8 var_wifi_signal = 0;
int var_hours = 0;
int var_minutes = 0;
int var_seconds = 0;
int var_days = 0;
int var_months = 0;
int var_years = 0;
float var_afk_time = 0;
double var_dpad_scroll_speed0 = DPAD_SCROLL_SPEED0_DEFAULT;
double var_dpad_scroll_speed1 = DPAD_SCROLL_SPEED1_DEFAULT;
double var_dpad_scroll_speed1_threshold = DPAD_SCROLL_THRESHOLD_DEFAULT;
double var_dpad_scroll_speed1_threshold_legacy = DPAD_SCROLL_THRESHOLD_DEFAULT;
int var_free_linear_ram = 0;
int var_lcd_brightness = 100;
int var_time_to_turn_off_lcd = 150;
int var_screen_off_mode = 0;
int var_num_of_app_start = 0;
int var_system_region = 0;
bool var_app_suspended = false;
int var_community_image_size = COMMUNITY_IMAGE_SIZE_DEFAULT;
double var_scroll_speed = 0.5;
char var_status[128];
std::string var_clipboard = "";
std::string var_lang = "en";
std::string var_lang_content = "en";
u8 var_model;
C2D_Image var_square_image[1];
C2D_Image var_texture_thumb_up[2];
C2D_Image var_texture_thumb_down[2];
